Quarantine and Contact Tracing (QCT)

Acknowledgement : @jojoldu <br>
https://github.com/jojoldu/freelec-springboot2-webservice

